# Sesion 7

library(tidyverse)
library(fredr)
library(forecast)

# Datos ----
cpi <- fredr(
  series_id = "CPIAUCSL",
  observation_start = as.Date("2000-01-01"),
  frequency = "m",
  units = "lin"
) |> 
  select(-c(series_id, realtime_start, realtime_end)) |>  
  mutate(
    yoy = (value/lag(value, 12) - 1) * 100,
    d1 = value - lag(value, 1)
  ) |> 
  na.omit()

# Plots -----

cpi |> 
  ggplot(aes(x = date)) +
  geom_line(aes(y = d1)) +
  labs(
    title = "CPI USA",
    subtitle = "Variación mensual",
    x = "",
    y = "", 
    color = NULL
  ) +
  theme_minimal() +
  theme(legend.position = "none") +
  scale_x_date(
    breaks = "2 years",
    date_labels = "%Y"
  )

# ARIMA ----


# SARIMA ----

# PACF


# SARIMA ----


# ARIMA + Xregs ----

# Dummy
xregs <- data.frame(date = cpi$date) |> 
  mutate(dummy = 0,
         dummy = ifelse(date %in% as.Date(c("2008-10-01", "2008-11-01",
                                            "2022-07-01")),
                        1,0)
  )

# Modelo



# WTI
wti <- fredr(
  series_id = "DCOILWTICO",
  observation_start = as.Date("2001-01-01"),
  frequency = "m",
  units = "pch"
) |> 
  select(-c(series_id, realtime_start, realtime_end)) |> 
  rename(wti = value)

xregs <- left_join(
  x = xregs,
  y = wti,
  by = c("date")
)

# Modelo


cpi |> 
  mutate(
    aa = fitted(aa)
  ) |> 
  select(-c(value, yoy)) |> 
  pivot_longer(cols = !date, 
               names_to = "series_id",
               values_to = "value") |> 
  ggplot(
    mapping = aes(
      x = date,
      y = value,
      color = series_id
    )
  ) +
  geom_line(linewidth = 1) +
  theme_minimal()



