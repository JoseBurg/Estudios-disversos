# Graficos y tablas
# Sesion 1

# Librerias ----
library(tidyverse)
library(fredr)
library(ggridges)

# Datos ----
wti <- fredr(
  series_id = "DCOILWTICO",
  observation_start = as.Date("2000-01-01"),
  frequency = "m",
  units = "pc1"
  ) 

# Estadistica descriptiva ----

wti |> 
  ggplot(
    mapping = aes(
      x = date,
      y = value
    )
  )  +
  geom_line()

# Incondicional
summary(wti$value)

# Condicional (años)
desc_stats <- wti 

# Densidad incondicional
wti |> 
  ggplot(aes(x = value)) +
  geom_density() +
  geom_vline(
    mapping = aes(
      xintercept = mean(value)
    )
  ) + 
  theme_minimal()

# Densidad condicional (años)
wti |> 
  filter(year >= 2015) |> 
  ggplot(
    mapping = aes(
      x = value,
      y = as.factor(year)
    )
  ) +
  geom_density_ridges() +
  theme_minimal()

# Analisis estacional ----

p_electricity <- fredr(
  series_id = "APU000072610", # precio promedio de kwH en USA
  observation_start = as.Date("2015-01-01"),
  frequency = "m",
  units = "lin"
) |> 
  select(-c(series_id, realtime_start, realtime_end)) |> 
  mutate(
    year = year(date),
    month = month(date)
  )

p_electricity |> 


# Estacional
p_electricity |> 


p_electricity |> 


# Inflacion USA ----
usa_inf <- map_dfr(c("CPIAUCSL", "DCOILWTICO", "PFOODINDEXM"), 
                   fredr,
                   observation_start = as.Date("2000-01-01"),
                   frequency = "m",
                   units = "pc1") |> 
  select(-c(realtime_start, realtime_end))

usa_inf |> 


usa_inf |> 





