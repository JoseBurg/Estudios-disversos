#Secretaría Ejecutiva del COnsejo Monetario Centroamericano
#Taller Series de Tiempo utilizando R 
#práctica 5
#Wilfredo Díaz & Juan Quiñonez

install.packages("readxl")
install.packages("TSstudio")
install.packages("tseries")
install.packages("dplyr")
install.packages("xts")
install.packages("BSDA")

library(readxl) # https://cran.r-project.org/web/packages/readxl/readme/README.html
library(TSstudio) # https://rpubs.com/ramkrisp/TSstudio
library(tseries) # https://cran.r-project.org/web/packages/tseries/tseries.pdf
library(dplyr) # https://rsanchezs.gitbooks.io/rprogramming/content/chapter9/dplyr.html
library(xts) # https://www.datacamp.com/cheat-sheet/xts-cheat-sheet-time-series-in-r?utm_source=google&utm_medium=paid_search&utm_campaignid=21057859163&utm_adgroupid=157296747057&utm_device=c&utm_keyword=&utm_matchtype=&utm_network=g&utm_adpostion=&utm_creative=692112540400&utm_targetid=dsa-2219652735776&utm_loc_interest_ms=&utm_loc_physical_ms=9070294&utm_content=DSA~blog~R-Programming&utm_campaign=230119_1-sea~dsa~tofu_2-b2c_3-es-lang-en_4-prc_5-na_6-na_7-le_8-pdsh-go_9-na_10-na_11-na-feb24&gad_source=1&gclid=CjwKCAiA6KWvBhAREiwAFPZM7jWrfUZnposxL2gleOZ88YyQvW1BCEzicSUcMTHVZ9dOenlR6vKH3hoCaxIQAvD_BwE
library(BSDA) #https://cran.r-project.org/web/packages/BSDA/index.html


#Elaboremos un proceso de generación de datos del tipo Yt=a + bYt-1+e
#en este caso utilizaremos la función rnorm

y <- c(1,30)
y[1]=0
y[2]=0
a=1
b=0.1 #que sucede si -1 < b <  1, que sucede si b<-1,b > 1
c=0.1
T=1
for (i in 3:30) {
  y[i]=b*y[i-1]+c*y[i-2]+rnorm(30)+a#+T*i
  
}

y <-  ts(y, start = c(1994, 1), frequency =1)

ts_info(y)

plot(y)

mean(y[1:30])
sd(y[1:30])

t.test(y[1:15], mu=35.8935)


#Pruebas de raíz unitaria 

acf(y)
pacf(y)
adf.test(y, k=1)  #test dickey fuller aumentado, importante el valor de k ---- rezagos
pp.test(y)

adf.test(diff(y), k=1) #en diferencias (diff)
pp.test(diff(y))
#conclusiones sobre el grado de integración


#Ejericio con datos reales

ejercicio <- read_excel(file.choose())


class(ejercicio)

ejercicio1 <-  ts(ejercicio[,2], start = c(2006, 1), frequency =12)

ts_info(ejercicio1[,1])

plot(ejercicio1[,1])

acf(ejercicio1[,1])
pacf(ejercicio1[,1])
adf.test(ejercicio1[,1], k=1) #test dickey fuller aumentado, importante el valor de k ---- rezagos
pp.test(ejercicio1[,1])

adf.test(diff(ejercicio1[,1]), k=1)
pp.test(diff(ejercicio1[,1]))


rm(list=ls())
