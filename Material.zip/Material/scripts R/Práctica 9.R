#Secretaría Ejecutiva del COnsejo Monetario Centroamericano
#Taller Series de Tiempo utilizando R 
#práctica 9
#Wilfredo Díaz & Juan Quiñonez

install.packages("readxl")
install.packages("TSstudio")
install.packages("tseries")
install.packages("dplyr")
install.packages("xts")
install.packages("x12")
install.packages("stats")
install.packages("forecast")
install.packages("urca")
install.packages("dynlm")
install.packages("ecm")
install.packages("modelr")
install.packages("dynamac")
install.packages("tidyverse")
install.packages("ARDL")
install.packages("fastDummies")
install.packages("vars")

library(readxl) # https://cran.r-project.org/web/packages/readxl/readme/README.html
library(TSstudio) # https://rpubs.com/ramkrisp/TSstudio
library(tseries) # https://cran.r-project.org/web/packages/tseries/tseries.pdf
library(dplyr) # https://rsanchezs.gitbooks.io/rprogramming/content/chapter9/dplyr.html
library(xts) # https://www.datacamp.com/cheat-sheet/xts-cheat-sheet-time-series-in-r?utm_source=google&utm_medium=paid_search&utm_campaignid=21057859163&utm_adgroupid=157296747057&utm_device=c&utm_keyword=&utm_matchtype=&utm_network=g&utm_adpostion=&utm_creative=692112540400&utm_targetid=dsa-2219652735776&utm_loc_interest_ms=&utm_loc_physical_ms=9070294&utm_content=DSA~blog~R-Programming&utm_campaign=230119_1-sea~dsa~tofu_2-b2c_3-es-lang-en_4-prc_5-na_6-na_7-le_8-pdsh-go_9-na_10-na_11-na-feb24&gad_source=1&gclid=CjwKCAiA6KWvBhAREiwAFPZM7jWrfUZnposxL2gleOZ88YyQvW1BCEzicSUcMTHVZ9dOenlR6vKH3hoCaxIQAvD_BwE
library(x12)  #paqueteX13- ARIMA https://www.jstatsoft.org/article/download/v062i02/811
library(stats) #https://www.rdocumentation.org/packages/stats/versions/3.6.2
library(forecast) #https://cran.r-project.org/web/packages/forecast/index.html
library(urca)  #https://cran.r-project.org/web/packages/urca/urca.pdf
library(jtools) #https://cran.r-project.org/web/packages/jtools/index.html
library(modelr) #https://cran.r-project.org/web/packages/modelr/index.html
library(dynamac) #https://rdrr.io/cran/dynamac/man/dynardl.html
library(tidyverse) #https://cran.r-project.org/web/packages/tidyverse/index.html
library(ARDL) #https://cran.r-project.org/web/packages/ARDL/index.html
library(lmtest) #https://cran.r-project.org/web/packages/lmtest/index.html
library(fastDummies) #https://cran.r-project.org/web/packages/fastDummies/fastDummies.pdf
library(dynlm) #https://cran.r-project.org/web/packages/dynlm/dynlm.pdf
library(vars)

 #buscar archivo en computador

coint <- read_excel(file.choose())

class(coint)

#como  serie de tiempo

coint2 <-  ts(coint[,3:7], start = c(2006, 1), end=c(2023, 10), frequency =12)

class(coint2)

ts_info(coint2)

options(scipen=999)

#pruebas de raíz unitaria 

acf(log(coint2[,"IMAE"]))
pacf(log(coint2[,"IMAE"]))
adf.test(log(coint2[,"IMAE"]), k=6)
pp.test(coint2[,"IMAE"])

acf(log(coint2[,"IPC"]))
pacf(log(coint2[,"IPC"]))
adf.test(log(coint2[,"IPC"]), k=1)
pp.test(coint2[,"IPC"])

acf(log(coint2[,"M1"]))
pacf(log(coint2[,"M1"]))
adf.test(log(coint2[,"M1"]), k=6)
pp.test(coint2[,"M1"])

acf(coint2[,"interes"])
pacf(coint2[,"interes"])
adf.test(coint2[,"interes"], k=1)
pp.test(coint2[,"interes"])

acf(coint2[,"WTI"])
pacf(coint2[,"WTI"])
adf.test(coint2[,"WTI"], k=3)
pp.test(coint2[,"WTI"])


adf.test(diff(log(coint2[,"IMAE"])), k=1)
pp.test(diff(log(coint2[,"IMAE"])))

adf.test(diff(log(coint2[,"IPC"])), k=1)
pp.test(diff(log(coint2[,"IPC"])))

adf.test(diff(log(coint2[,"M1"])), k=1)
pp.test(diff(log(coint2[,"M1"])))

adf.test(diff(coint2[,"interes"]), k=1)
pp.test(diff(coint2[,"interes"]))

adf.test(diff(log(coint2[,"WTI"])), k=1)
pp.test(diff(log(coint2[,"WTI"])))

#Test Engel y Granger

regresion <- tslm(log(coint2[,"IPC"]) ~ 1 +log(coint2[,"IMAE"])+log(coint2[,"M1"])+ coint2[,"interes"] +log(coint2[,"WTI"]))
summary(regresion)

resid= residuals(regresion)
ts_info(resid)

acf(resid)
pacf(resid)
adf.test(resid, k=1)
pp.test(resid)

#Prueba de Phillips-Ouliaris 

pruebacoint <- ca.po(coint2, demean="none", type="Pz")
summary(pruebacoint)



#Prueba Johansen

firstvar=VARselect(coint2, lag.max =12, season=12)
summary(firstvar)


# S3 method for varest

jotest=ca.jo(coint2, type="eigen", K=4, ecdet="none", spec="longrun", season=12) #es posible agregar dummies
summary(jotest)

serieestacionaria= 1*coint2[,1] +  -0.13268724*coint2[,2] + 0.01556279*coint2[,3] -0.23579920*coint2[,4] + -0.21508416*coint2[,5]
plot(serieestacionaria, type="l")

adf.test(serieestacionaria,k=1)
pp.test(serieestacionaria)


#Modelos ARDL y de corrección de erores (ECM)

#dummies
#estacionales
coint= dummy_cols(coint, select_columns ="Mes")
#observaciones extremas
coint$dum1 = 0
coint[23,20]=1

coint$dum2 = 0
coint[159,21]=1

#transformación en logartimos
coint3= coint[1:204,]
coint3[,3:5]=log(coint3[,3:5])
coint3[,7]=log(coint3[,7])

coint2 <-  ts(coint[,3:21], start = c(2006, 1), end=c(2022, 12), frequency =12)

coint4 <-  ts(coint[,3:21], start = c(2023, 1), end=c(2023, 12), frequency =12)
coint4[,1:3]=log(coint4[,1:3])
coint4[,5]=log(coint4[,5])



#Usando dynlm


regresion2= dynlm(d(log(IPC)) ~ -1+ L(log(IPC),1)+L(log(IMAE),1)+L(interes,1)
                  +L(log(WTI),1)
                  +d(interes)+d(log(WTI)) 
                  +L(d(log(IPC)),1)+L(d(log(IMAE)),c(1,5))
                  + Mes_2+ Mes_8+ Mes_11+dum1+dum2
                  ,data=coint2)
summary(regresion2)

checkresiduals(regresion2)
shapiro.test(residuals(regresion2))
bgtest(regresion2)
bptest(regresion2)

resid2=residuals(regresion2)

show(resid2)

ts.plot(diff(log(coint2[,"IPC"])),
        main='ajuste de la regresión',
        ylab='inflación mensual',
        xlab='año')
fit <- fitted(regresion2)
points(fit, type = "l", col = 2, lty = 2)

#predict(regresion3, coint4 ) #no se pueden hacer regresiones con este paquete


#Utilizando dynardl

regresion3=  dynardl(IPC ~ IMAE + WTI +interes+Mes_2+Mes_8+Mes_11 +dum1+dum2, data=coint3, 
                     lags=list("IPC"=1,"WTI"=1,"interes"=1,"IMAE"=1), 
                     diff=c( "WTI", "interes"),
                     lagdiffs = list(  "IMAE"=c(1,5),
                                       "IPC"=c(1)),
                     levels = c("Mes_2","Mes_8", "Mes_11", "dum1", "dum2"),
                     ec=TRUE, constant = FALSE , trend=FALSE, simulate=TRUE, shockvar="WTI", shockval=0, time =3, range=6, 
                      modelout=TRUE, forceset = list("IMAE"=4.603369, "WTI"=4.181897,"interes"=8.046996,"Mes_2"=0,
                                                     "IMAE"=4.528181, "WTI"=4.121149,"interes"=6.993971,"Mes_2"=1,
                                                     "IMAE"=4.608564,"WTI"=4.138202,"interes"=7.318564, "Mes_2"=0,
                                                     "IMAE"=4.504797, "WTI"=4.240463,"interes"=3.554719, "Mes_2"=0,
                                                     "IMAE"=4.599554, "WTI"=4.260424,"interes"=3.663156, "Mes_2"=0,
                                                     "IMAE"= 4.601263,"WTI"=4.261975,"interes"=7.378136,"Mes_2"=0) )
#cuanto es una desviación standar

sd(coint2[,"WTI"]) #en niveless
sd(log(coint2[,"WTI"])) #en logaritmos


dynardl.auto.correlated(regresion3) #análisis de la regresión

dynardl.simulation.plot(regresion3,response = "diffs") #gráfico de la respuesta de la simulación.

#ajsute del modelo

datosfit=regresion3$model
fit=datosfit$fitted.values

fit=ts(fit,start = c(2006, 6), end=c(2022, 12), frequency =12)
show(fit)

plot(diff(log(coint2[,"IPC"])), ylab="Inflación Mensual", xlab="meses/años")
lines(fit, type="l", col="blue")
legend("topright", legend = c("obs", "Fitted"), 
       col = c( "black","blue"), lty = 2, horiz=TRUE, cex=0.6)


#pronósito a varios perídos (sin shocks) usando forceset.

simu=regresion3$simulation
simuresult=simu$d.central

simuresult=ts(simuresult,start = c(2023, 1), end=c(2023, 6), frequency =12)
ts_info(simuresult)
plot(simuresult)
show(simuresult)

infla=ts(diff(log(coint4[1:6,"IPC"])),start = c(2023, 1), end=c(2023, 6), frequency =12)
show(infla)

plot(infla, ylab="Inflación Mensual", xlab="meses/años")
lines(simuresult, type="l", col="blue")
legend("topright", legend = c("obs", "Fitted"), 
       col = c( "black","blue"), lty = 2, horiz=TRUE, cex=0.6)



rm(list=ls())

