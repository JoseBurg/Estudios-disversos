# Funciones utilitarias

get_aic <- function(x) {
  
  mod <- .GlobalEnv[[x]]
  
  stats <- data.frame(
    order = paste0(
      "(", mod[["call"]][["order"]][[2]], ",", 
      mod[["call"]][["order"]][[3]], ",",
      mod[["call"]][["order"]][[4]],")"
    ),
    aic = mod[["aic"]]
  )
  
  return(stats)
}

best_arima <- function(ord) {
  model <- arima(x = cpi$d1,
                 order = ord)
  
  stats <- data.frame(
    order = paste0(ord, collapse = ","),
    aic = model[["aic"]]
  )
  
  return(stats)
  
}