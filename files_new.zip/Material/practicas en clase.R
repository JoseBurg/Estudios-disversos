library(tidyverse)
library(fredr)
library(forecast)
library(tseries)

imae <- readxl::read_excel("./datos en excel/IMAE.xlsx") |>
  janitor::clean_names() |> 
  mutate(
    yoy = (imae/lag(imae, 12) - 1) * 100,
    d1 = imae - lag(imae, 1),
    fecha = paste0(fecha, "-01"))
