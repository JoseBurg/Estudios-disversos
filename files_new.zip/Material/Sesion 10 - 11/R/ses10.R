# Sesion 9

# Libraries ----
library(vars)
library(tseries)
library(forecast)
library(tidyverse)
library(fredr)

source("./Sesion 10 - 11/R/interp_urdf.R")

# Datos ----
# usa_inf <- map_dfr(c("CPIAUCSL", "DCOILWTICO"), 
#                    fredr,
#                    observation_start = as.Date("2000-01-01"),
#                    observation_end = as.Date("2023-12-01"),
#                    frequency = "m",
#                    units = "lin") |> 
#   select(-c(realtime_start, realtime_end)) |> 
#   pivot_wider(
#     names_from = "series_id",
#     values_from = "value"
#   )

inflacion_usa <- readxl::read_excel("./datos en excel/usa_inf_2000.xlsx")

cpi <- ts(
  data = inflacion_usa$CPIAUCSL,
  start = c(2000, 1),
  frequency = 12)

oil <- ts(
  data = inflacion_usa$DCOILWTICO,
  start = c(2000, 1),
  frequency = 12
)

# Plots
autoplot(cpi, series = "CPI") +
  autolayer(oil, series = "OIL") +
  theme_minimal()

# Pruebas de Raiz unitarias ----

# CPI
ur_cpi <- urca::ur.df(
  y = cpi,
  type = "trend"
)

summary(ur_cpi)
interp_urdf(ur_cpi)

dcpi <- diff(cpi, lag = 1)

ur_dcpi <- urca::ur.df(
  y = dcpi,
  type = "trend"
)

summary(ur_dcpi)
interp_urdf(ur_dcpi)                               # Conclusión de un test


# OIL
ur_oil <- urca::ur.df(
  y = oil,
  type = "none"
)

summary(ur_oil)
interp_urdf(ur_oil)

doil <- diff(oil, lag = 1)

ur_doil <- urca::ur.df(
  y = doil,
  type = "none"
)

summary(ur_doil)
interp_urdf(ur_doil)

#                                                    VAR ----
x <- cbind(doil, dcpi)

#                                                    Seleccion de rezagos del VAR
VARselect(x,lag.max = 12)

#                                                     Modelo
inf_var <- VAR(
  y = x,
  p = 6,
  type = "const"
)

inf_var

stargazer::stargazer(inf_var$varresult, type = "text")

# Pruebas ----

# Autocorrelacion
serial.test(
  x = inf_var,
  lags.pt = 12,
  type = "PT.asymptotic"
  )

#                             Raices del polinomio caracteristico
df_roots <- data.frame(
  real = Re(roots(inf_var, modulus = FALSE )),
  imaginary = Im(roots(inf_var, modulus = FALSE )))

ggplot() +
  ggforce::geom_circle(data = tibble::tibble(x = 0, y = 0), aes(x0 = x, y0 = y, r = 1)) +
  geom_point(data = df_roots, aes(x = real, y = imaginary)) +
  coord_fixed(ratio = 1) +
  geom_hline(yintercept = 0) +
  geom_vline(xintercept = 0) +
  theme_minimal()

# Causalidad ----
dcpi_causes_doil <- causality(
  x = inf_var,
  cause = "dcpi"
)

dcpi_causes_doil


doil_causes_dcpi <- causality(
  x = inf_var,
  cause = "doil"
)

doil_causes_dcpi

#                                                     Impulso Respuesta ----
irf.dcpi <- irf(
  x = inf_var,
  impulse = "doil",
  response = "dcpi",
  n.ahead = 24
)
plot(irf.dcpi)

# Pronosticos ----
proy <- predict(
  object = inf_var,
  n.ahead = 12
)
autoplot(proy)

fanchart(
  x = proy,
  names = "dcpi"
)


# Descomposicion de varianza ----  Como una variable explica a otra variable según los 
vardec <- fevd(inf_var, n.ahead = 12)
plot(vardec)


#                                                                        Modelo Estructural ----

#                                                             Datos ----
# usa_inf <- map_dfr(c("CPIAUCSL", "DCOILWTICO", "CPIENGSL"),
#                    fredr,
#                    observation_start = as.Date("2000-01-01"),
#                    observation_end = as.Date("2023-12-01"),
#                    frequency = "m",
#                    units = "lin") |>
#   select(-c(realtime_start, realtime_end)) |>
#   pivot_wider(
#     names_from = "series_id",
#     values_from = "value"
#   )

usa_inf <- readxl::read_excel("./datos en excel/usa_completo.xlsx")

nrg <- ts(
  data = usa_inf$CPIENGSL,
  start = c(2000, 1),
  frequency = 12
)

autoplot(nrg)

# Pruebas de Raiz unitarias ----

# Energy
ur_nrg <- urca::ur.df(
  y = nrg,
  type = "trend"
)

summary(ur_nrg)
interp_urdf(ur_nrg)

dnrg <- diff(nrg, lag = 1)

ur_dnrg <- urca::ur.df(
  y = dnrg,
  type = "trend"
)

summary(ur_dnrg)
interp_urdf(ur_dnrg)

# VAR Estructural ----
x <- cbind(doil, dnrg, dcpi)

# Seleccion de rezagos del VAR
VARselect(x,lag.max = 12)

# Modelo
inf_var <- VAR(
  y = x,
  p = 6,
  type = "const"
)

#VAR Estructural Restricciones de Corto plazo 

# Matriz de restricciones de efectos contemporaneos
amat <- diag(3)
amat[2,1] <- NA
amat[3,1] <- NA 
amat

# Restricciones asociadas a los residuos
bmat <- diag(3)
diag(bmat) <- NA
bmat


mod.svar <- SVAR(inf_var,
                 Amat = amat,
                 Bmat = bmat)


# Impulso Respuesta ----
irf.svar <- irf(
  x = mod.svar,
  impulse = "doil",
  response = "dcpi",
  n.ahead = 24     
)
plot(irf.svar)

irf.var <- irf(
  x = inf_var,
  impulse = "doil",
  response = "dcpi",
  n.ahead = 24
)
plot(irf.var)


# Pronosticos ----
proy <- predict(
  object = inf_var,
  n.ahead = 12
)
autoplot(proy)

fanchart(
  x = proy,
  names = "dcpi"
)


# Descomposicion de varianza ----
vardec <- fevd(inf_var, n.ahead = 12)
plot(vardec)




# Practica ---------------------------------------------------------------
coint <- read_excel("./datos en excel/coint.xlsx") |> 
  mutate(across(
    c(IMAE, IPC, WTI),
    \(x) log(x) - lag(log(x))))

coint_ts <- ts(
  data = coint[,c("IMAE", "IPC", "WTI")],
  start = c(2006,1),
  frequency = 12
)
