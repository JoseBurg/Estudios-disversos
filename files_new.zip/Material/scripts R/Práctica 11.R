#Secretaría Ejecutiva del COnsejo Monetario Centroamericano
#Taller Series de Tiempo utilizando R 
#práctica 11
#Wilfredo Díaz & Juan Quiñonez

install.packages("readxl")
install.packages("tsDyn")
install.packages("TSstudio")
install.packages("tseries")
install.packages("dplyr")
install.packages("xts")
install.packages("forecast")
install.packages("urca")
install.packages("vars")
install.packages("MTS")
install.packages("RVAideMemoire")
install.packages("fastDummies")

library(readxl) # https://cran.r-project.org/web/packages/readxl/readme/README.html
library(tsDyn) #https://cran.r-project.org/web/packages/tsDyn/tsDyn.pdf
library(TSstudio) # https://rpubs.com/ramkrisp/TSstudio
library(tseries) # https://cran.r-project.org/web/packages/tseries/tseries.pdf
library(dplyr) # https://rsanchezs.gitbooks.io/rprogramming/content/chapter9/dplyr.html
library(xts) # https://www.datacamp.com/cheat-sheet/xts-cheat-sheet-time-series-in-r?utm_source=google&utm_medium=paid_search&utm_campaignid=21057859163&utm_adgroupid=157296747057&utm_device=c&utm_keyword=&utm_matchtype=&utm_network=g&utm_adpostion=&utm_creative=692112540400&utm_targetid=dsa-2219652735776&utm_loc_interest_ms=&utm_loc_physical_ms=9070294&utm_content=DSA~blog~R-Programming&utm_campaign=230119_1-sea~dsa~tofu_2-b2c_3-es-lang-en_4-prc_5-na_6-na_7-le_8-pdsh-go_9-na_10-na_11-na-feb24&gad_source=1&gclid=CjwKCAiA6KWvBhAREiwAFPZM7jWrfUZnposxL2gleOZ88YyQvW1BCEzicSUcMTHVZ9dOenlR6vKH3hoCaxIQAvD_BwE
library(forecast) #https://cran.r-project.org/web/packages/forecast/index.html
library(urca)  #https://cran.r-project.org/web/packages/urca/urca.pdf
library(vars) #https://cran.r-project.org/web/packages/vars/index.html
library(MTS) #https://cran.r-project.org/web/packages/MTS/index.html
library(RVAideMemoire) #https://cran.r-project.org/web/packages/RVAideMemoire/index.html
library(fastDummies) #https://cran.r-project.org/web/packages/fastDummies/fastDummies.pdf

options(scipen=999)

#coint.xl
coint <- read_excel("./datos en excel/coint.xlsx")
coint=coint[,-5]#quitar M1

coint2 <-  ts(coint[,3:6], start = c(2006, 1), end=c(2023, 12), frequency =12)



#pruebas de raíz unitaria 

acf(log(coint2[,"IMAE"]))
pacf(log(coint2[,"IMAE"]))
adf.test(log(coint2[,"IMAE"]), k=6)
pp.test(coint2[,"IMAE"])

acf(log(coint2[,"IPC"]))
pacf(log(coint2[,"IPC"]))
adf.test(log(coint2[,"IPC"]), k=1)
pp.test(coint2[,"IPC"])

acf(coint2[,"interes"])
pacf(coint2[,"interes"])
adf.test(coint2[,"interes"], k=1)
pp.test(coint2[,"interes"])

acf(coint2[,"WTI"])
pacf(coint2[,"WTI"])
adf.test(coint2[,"WTI"], k=3)
pp.test(coint2[,"WTI"])

# preparación de datos:

#tomaremos a WTI como una variable exógena
wti = log(coint2[,4])
wti = diff(wti,1) #pierde una observación 2006 feb 2023 oct, importante tenerlo en cuenta
ts_info(wti)

#                                                  dummies por mes
coint = dummy_cols(coint, select_columns ="Mes")

#observaciones extremas
coint$dum1 = 0
coint[23,19] = 1       # Porque se escogio esta dummy

coint$dum2 = 0
coint[159,20]=1

coint$dum3=0
coint[150,21]=1

coint$dum4=0
coint[54,22]=1

coint$dum5=0
coint[55,23]=1

coint$dum6=0
coint[172,24]=1


#  Preparación de datos para estimación -----------------------------------


# Las dummies hay que sacarla de los datos para luego agregarla como exogenas al modelo de estimación

coint3 = ts(coint[,3:24], start = c(2006, 2), end=c(2022, 12), frequency =12)
coint3=coint3[,-4]
coint3[,1:2] = log(coint3[,1:2])

wtim = ts(wti, start = c(2006, 2), end=c(2022, 12), frequency =12)


# Separación de variables y dummies
vecdata=coint3[,1:3]


dummies = coint3[,4:21]
dummies = dummies[,-3:-7]
exodatamodel = ts.union(wtim,dummies)

# Datos para  pronosticar -------------------------------------------------
coint4 <-  ts(coint[,3:24], start = c(2023, 1), end=c(2023, 12), frequency =12)

vecdatafore=coint4[,1:3]
vecdatafore=log(vecdatafore)


dummiesf=coint4[,5:22]
dummiesf=dummiesf[,-3:-7]


wtifore=ts(wti,start = c(2023, 1), end=c(2023, 12), frequency =12)


exodatafore = ts.union(wtifore,dummiesf)



# Estimación del VECM -----------------------------------------------------

#                     prueba de cointegración.
jotest=ca.jo(vecdata, type="eigen", K=2, ecdet="none", spec="longrun", seas=4) #es posible agregar dummies
summary(jotest)

# Valores del resumen (summary(jotest))
serieestacionaria=1*vecdata[,1]  -0.66551406*vecdata[,2] -0.01282724*vecdata[,3] 
plot(serieestacionaria, type="l")

adf.test(serieestacionaria, k=1)
pp.test(serieestacionaria)

primerVECM = VECM(
  vecdata, lag = 1, 
  r = 1, # Cointegración no.1 
  include = c("const"), 
  beta = NULL, estim="ML", 
  LRinclude = c( "none"), 
  exogen = exodatamodel
)
summary(primerVECM)


#                                     diagnóstico

resid=residuals(primerVECM)

class(resid)

resid= ts(resid,start = c(2006, 1), end=c(2022, 12), frequency =12)

class(resid)

show(resid)

plot(resid)

mq(resid,12)                         #test de autocorrelación conjunta
# Significancia hasta los 11 rezagos

mshapiro.test(resid)                 #test de normalidad conjunta
# H0: Hay normalidad en los errores
# H1: No Hay normalidad en los errores

#Pronóstico

vecdatafore = ts(vecdatafore[1:2,1:3],start = c(2023, 1), end=c(2023, 2), frequency =12)

Fore = predict(primerVECM,newdata=vecdatafore,exoPred =exodatafore, n.ahead=12 )
Fore = ts(Fore,start = c(2023, 1), end=c(2023, 12), frequency =12)
plot(diff(Fore[,"IPC"]))

HW = HoltWinters(diff(vecdata[,"IPC"]),alpha=0.6, beta=0.3, gamma=0.3 ) # para conocer sobre el méotdo HW https://rpubs.com/nanrosvil/283121
forhW = predict(HW, 12, prediction.interval = FALSE, level=0.95)
plot(forhW)

plot(diff(log(coint4[,"IPC"])), ylab="Inflación Mensual", xlab="meses/años")
lines(diff(Fore[,"IPC"]), type="l", col="blue")
lines(forhW, type="l", col="green")
legend("bottomleft", legend = c("obs", "VECM", "HW"), 
       col = c( "black","blue","green"), lty = 1, horiz=TRUE, cex=0.6)


#                                                                              Evaluando pronóstico
evecm =diff(Fore[,"IPC"])- diff(log(coint4[,"IPC"]))
eHW=forhW  - diff(log(coint4[,"IPC"]))

MSEevecm=(1/12)*(sum(evecm))^2
MSEeHW=(1/12)*(sum(eHW))^2

RMSEevecm=(MSEevecm)^1/2
RMSEeHW=(MSEeHW)^1/2


rm(list=ls())

