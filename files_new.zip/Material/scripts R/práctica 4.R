#Secretaría Ejecutiva del COnsejo Monetario Centroamericano
#Taller Series de Tiempo utilizando R 
#práctica 4
#Wilfredo Díaz & Juan Quiñonez

install.packages("readxl")
install.packages("TSstudio")
install.packages("tseries")
install.packages("dplyr")
install.packages("xts")
install.packages("x12")

library(readxl) # https://cran.r-project.org/web/packages/readxl/readme/README.html
library(TSstudio) # https://rpubs.com/ramkrisp/TSstudio
library(tseries) # https://cran.r-project.org/web/packages/tseries/tseries.pdf
library(dplyr) # https://rsanchezs.gitbooks.io/rprogramming/content/chapter9/dplyr.html
library(xts) # https://www.datacamp.com/cheat-sheet/xts-cheat-sheet-time-series-in-r?utm_source=google&utm_medium=paid_search&utm_campaignid=21057859163&utm_adgroupid=157296747057&utm_device=c&utm_keyword=&utm_matchtype=&utm_network=g&utm_adpostion=&utm_creative=692112540400&utm_targetid=dsa-2219652735776&utm_loc_interest_ms=&utm_loc_physical_ms=9070294&utm_content=DSA~blog~R-Programming&utm_campaign=230119_1-sea~dsa~tofu_2-b2c_3-es-lang-en_4-prc_5-na_6-na_7-le_8-pdsh-go_9-na_10-na_11-na-feb24&gad_source=1&gclid=CjwKCAiA6KWvBhAREiwAFPZM7jWrfUZnposxL2gleOZ88YyQvW1BCEzicSUcMTHVZ9dOenlR6vKH3hoCaxIQAvD_BwE
library(x12)  #paqueteX13- ARIMA https://www.jstatsoft.org/article/download/v062i02/811



#IMAE.xlsx"

ejercicio <- read_excel("./datos en excel/IMAE.xlsx")


class(ejercicio)

ejercicio1 <- xts(ejercicio[,-1], order.by=as.yearmon(unlist(ejercicio[,1])))
ejercicio2 <-  ts(ejercicio[,2], start = c(2006, 1), frequency =12)

class(ejercicio1)
class(ejercicio2)

ts_info(ejercicio1[,"IMAE"])
ts_info(ejercicio2[,"IMAE"])


#la descomposición de una serie de tiempo 

plot(ejercicio1[,"IMAE"])


# Descomposición de series de tiempo tradiccional --------------------------------------
#usando decompose        

ts_decompose(ejercicio1[,"IMAE"],type="additive")  # Gráfico

decomp <-  decompose(ejercicio2[,"IMAE"],type="additive")                        # Descomposicion


#podemos graficar cada componente de la serie:
plot(decomp$trend,main = "Tendencia IMAE", xlab="meses", ylab="Indice") 

#trabajando con los componentes

imaeTC = decomp$x-decomp$seasonal - decomp$random                               # Descomponer, restando componentes                         

plot(ejercicio2[,"IMAE"], main = "Tendencia Ciclo vs Original", xlab="meses", ylab="Indice")
lines(imaeTC, type="l", col="blue")
legend("topleft", legend = c("IMAE", "IMAETC"), 
       col = c( "black","blue"), lty = 1)

##puede ser creativo/otras formas de hacer el trabajo

#estacionalidad

boxplot(ejercicio2[,"IMAE"]~cycle(ejercicio1[,"IMAE"]), xlab="mes", ylab="indice", main= "promedio por mes", col="green")


# Descomposicion por STL --------------------------------------------------
#usando STL

decomp2 = stl(ejercicio2[,"IMAE"], "periodic") #STL utiliza regresiones locales (LOESS)"


plot(stl(ejercicio2[,"IMAE"], "periodic", robust=TRUE))


#trabajando con los componentes de STL
plot(decomp2$time.series[,2])

# Descomposicion aditiva, 
# restando componentes:
#       (Serie original) - 
imaeTC2=ejercicio2[,"IMAE"]-decomp2$time.series[,1]-decomp2$time.series[,3]


plot(ejercicio2[,"IMAE"], main = "Tendencia Ciclo vs Original", xlab="meses", ylab="Indice")
lines(imaeTC2, type="l", col="blue")
legend("topleft", legend = c("IMAE", "IMAETC"), 
       col = c( "black","blue"), lty = 1)

#   La descomposición de una serie de tiempo X13-ARIMA-SEATS

resultados= x12(ejercicio2[,"IMAE"])

summary(resultados)


# Llamando a un dato en especifico con @
plot(resultados@d11)  #d10=estacional d11=tendencia/ciclo d12=tendencia d13=parte aleatoria # Importante

plot(resultados@d10) # Estacional
plot(resultados@d11) # Tendencia / ciclo
plot(resultados@d12) # Tendencia
plot(resultados@d13) # Parte aleatoria

plot(resultados, trend = TRUE, sa = TRUE, forecast = TRUE)


#X-13-ARIMA-SEATS editable

resultados2=new("x12Single", ts=ejercicio2[,"IMAE"])

# Ajuste para manipular el modelo: automdl sirve para darle directo el modelo que se quiere
resultados2=setP(resultados2,list(automdl=FALSE))
resultados2=setP(resultados2,list( arima.model=c(2,1,1), arima.smodel=c(2,1,1)))

resultados2= x12(resultados2)

summary(resultados2)

plot(resultados2, trend = TRUE, sa = TRUE,  forecast = TRUE)

rm(list=ls())


