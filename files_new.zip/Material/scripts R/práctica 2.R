#Secretaría Ejecutiva del COnsejo Monetario Centroamericano
#Taller Series de Tiempo utilizando R 
#práctica 2
#Wilfredo Díaz & Juan Quiñonez

install.packages("readxl")
install.packages("TSstudio")
install.packages("tseries")
install.packages("dplyr")
install.packages("xts")

library(readxl) # https://cran.r-project.org/web/packages/readxl/readme/README.html
library(TSstudio) # https://rpubs.com/ramkrisp/TSstudio
library(tseries) # https://cran.r-project.org/web/packages/tseries/tseries.pdf
library(dplyr) # https://rsanchezs.gitbooks.io/rprogramming/content/chapter9/dplyr.html
library(xts) # https://www.datacamp.com/cheat-sheet/xts-cheat-sheet-time-series-in-r?utm_source=google&utm_medium=paid_search&utm_campaignid=21057859163&utm_adgroupid=157296747057&utm_device=c&utm_keyword=&utm_matchtype=&utm_network=g&utm_adpostion=&utm_creative=692112540400&utm_targetid=dsa-2219652735776&utm_loc_interest_ms=&utm_loc_physical_ms=9070294&utm_content=DSA~blog~R-Programming&utm_campaign=230119_1-sea~dsa~tofu_2-b2c_3-es-lang-en_4-prc_5-na_6-na_7-le_8-pdsh-go_9-na_10-na_11-na-feb24&gad_source=1&gclid=CjwKCAiA6KWvBhAREiwAFPZM7jWrfUZnposxL2gleOZ88YyQvW1BCEzicSUcMTHVZ9dOenlR6vKH3hoCaxIQAvD_BwE

ejercicio <- read_excel("./datos en excel/IMAE.xlsx")

class(ejercicio)

ejercicio1 <- xts(ejercicio[,2], order.by= as.yearmon(unlist(ejercicio[,1])))


ejercicio2 <-  ts(ejercicio[,2], start = c(2006, 1), frequency =12)


class(ejercicio1)
class(ejercicio2)

ts_info(ejercicio1[,"IMAE"])                                           # Informaciones 
ts_info(ejercicio2[,"IMAE"])                                           # Informaciones 


plot(ejercicio1[,"IMAE"])  # XTS
plot(ejercicio2[,"IMAE"])  #ts


#funciones de autocorrelación y autocorrelación parcial

# autocorrelación -----------------------------------------
# Nos das información de la importancias 
# de los rezagos de la misma variable en el tiempo
acf(ejercicio1[,"IMAE"]) 

# autocorrelación parcial--------------------------------
# Nos das información del impacto de cada rezago
pacf(ejercicio1[,"IMAE"])

#Elaboremos un proceso de generación de datos
y <- c(1,30)
class(y)
y[1]=0
a=0.2
b=0.3
T=1
for (i in 2:30) {
  y[i]=a+b*y[i-1]+rnorm(30) + T * i#+a+T*i
  
}

y <-  ts(y, start = c(1994, 1), frequency =1)

ts_info(y)

plot(y)


#hagamos experimentos

mean(y)
sd(y)

acf(y)
pacf(y)


mean(y[1:15])
sd(y[1:15])

t.test(y, mu=mean(y[1:15]))

rm(list=ls())

#fin
