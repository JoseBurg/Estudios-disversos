#Secretaría Ejecutiva del COnsejo Monetario Centroamericano
#Taller Series de Tiempo utilizando R 
#práctica 8
#Wilfredo Díaz & Juan Quiñonez

install.packages("readxl")
install.packages("TSstudio")
install.packages("tseries")
install.packages("dplyr")
install.packages("xts")
install.packages("x12")
install.packages("stats")
install.packages("forecast")
install.packages("MLmetrics")

library(readxl) # https://cran.r-project.org/web/packages/readxl/readme/README.html
library(TSstudio) # https://rpubs.com/ramkrisp/TSstudio
library(tseries) # https://cran.r-project.org/web/packages/tseries/tseries.pdf
library(dplyr) # https://rsanchezs.gitbooks.io/rprogramming/content/chapter9/dplyr.html
library(xts) # https://www.datacamp.com/cheat-sheet/xts-cheat-sheet-time-series-in-r?utm_source=google&utm_medium=paid_search&utm_campaignid=21057859163&utm_adgroupid=157296747057&utm_device=c&utm_keyword=&utm_matchtype=&utm_network=g&utm_adpostion=&utm_creative=692112540400&utm_targetid=dsa-2219652735776&utm_loc_interest_ms=&utm_loc_physical_ms=9070294&utm_content=DSA~blog~R-Programming&utm_campaign=230119_1-sea~dsa~tofu_2-b2c_3-es-lang-en_4-prc_5-na_6-na_7-le_8-pdsh-go_9-na_10-na_11-na-feb24&gad_source=1&gclid=CjwKCAiA6KWvBhAREiwAFPZM7jWrfUZnposxL2gleOZ88YyQvW1BCEzicSUcMTHVZ9dOenlR6vKH3hoCaxIQAvD_BwE
library(x12)  #paqueteX13- ARIMA https://www.jstatsoft.org/article/download/v062i02/811
library(stats) #https://www.rdocumentation.org/packages/stats/versions/3.6.2
library(forecast) #https://cran.r-project.org/web/packages/forecast/index.html
library(MLmetrics) #MAPE https://cran.r-project.org/web/packages/MLmetrics/MLmetrics.pdf

ejercicio <- read_excel("./datos en excel/IMAE.xlsx")

class(ejercicio)

ejercicio2 <-  ts(ejercicio[,2], start = c(2006, 1), frequency =12)

#Vamos a trabajar con la tasa de crecimiento del IMAE

crecimae=diff(log(ejercicio2[,"IMAE"])) #tasa de crecimiento intermensual

plot(crecimae)

crecimae1=ts(crecimae, start=c(2006,2), end=c(2022,12), frequency = 12) #muestra para estimación.
crecimae2=ts(crecimae, start=c(2023,1), end=c(2023,12), frequency = 12) 

plot(crecimae1)



# Pronosticos  ------------------------------------------------------------


#1.                                                utilizando x12

resultado=x12(crecimae1)
summary(resultado)

forx13=resultado@forecast@estimate #pronóstico

class(forx13)
ts_info(forx13)

plot(forx13)

#2.                                               utilizando STL

decomp = stl(crecimae1, "periodic", robust=TRUE)

forestl = forecast(decomp, h=12)

forestl = forestl$mean

class(forestl)
ts_info(forestl)

plot(forestl)



#3.                                               utilizando AUTOARIMA

arim = auto.arima(crecimae1, approximation = FALSE, trace = FALSE)

forarim = predict(arim,12) #proyección 12 periodos a predecir
forarim = forarim$pred

class(forarim)
ts_info(forarim)

plot(forarim)

#4.                                               Holt-Winters

#El método de Holt Winters es utilizado para realizar pronósticos del 
#comportamiento de una serie temporal a partir de los datos obtenidos 
#anteriormente. El método se basa en un algoritmo iterativo que a cada 
#tiempo (mes o semana) realiza un pronóstico sobre el comportamiento de 
#la serie en base a promedios debidamente ponderados de los datos anteriores.

HW = HoltWinters(crecimae1, alpha = 0.6, beta = 0.3, gamma = 0.3)
# para conocer sobre el méotdo HW https://rpubs.com/nanrosvil/283121

# Notas:
# alfa: el “valor base”. Un alfa más alto otorga más peso a las observaciones más recientes.
# beta: el “valor de tendencia”. Una beta más alta significa que la pendiente de la tendencia depende más de las pendientes de la tendencia reciente.
# gamma: el “componente estacional”. Una gamma más alta otorga más peso a los ciclos estacionales más recientes.

forhW = predict(HW, 12, prediction.interval = FALSE, level=0.95) # 12 periodos

class(forhw)
ts_info(forhW)

plot(forhW)

#         promedio de los forecast
promfore = (forarim + forhW + forx13 + forestl)/4


plot(crecimae2, ylab="crecimiento IMAE", xlab="meses")
lines(forx13, type="l", col="blue")
lines(forarim, type="l", col="green")
lines(forhW, type="l", col="red")
lines(forestl,type="l", col="orange") 
lines(promfore,type="l", col="purple") 
legend("bottomright", legend = c("obs", "x13", "arima","HW","stl","prom"), 
 col = c( "black","blue","green","red","orange", "purple"), lty = 2, horiz=TRUE, cex=0.6)

###                 Evaluación de forecast adentro de muestra ----------------------------------------------

#1. errores de pronóstico
ex13=crecimae2 - forx13
earim=crecimae2 - forarim
ehw=crecimae2 -forhW
estl=crecimae2 - forestl
epromfore=crecimae2 - promfore

shapiro.test(ex13)              # Test de normalidad. H0: presencia de normalidad
mean(ex13)                      # Se busca que este cercano a 1
sd(ex13)                        # Se busca que este cercano a 0
shapiro.test(earim)
mean(earim)
sd(earim)
shapiro.test(ehw)
mean(ehw)
sd(ehw)
shapiro.test(estl)
mean(estl)
sd(estl)
mean(epromfore)
sd(epromfore)

###2. error cuadrático medio

MSEX13 = (1/12)*(sum(ex13))^2
MSEarim = (1/12)*(sum(earim))^2
MSEhw = (1/12)*(sum(ehw))^2
MSEstl = (1/12)*(sum(estl))^2
MSEpromfore=(1/12)*(sum(epromfore))^2

###3. raíz cuadrada del error cuadrático medio
RMSEX13=(MSEX13)^1/2
RMSEarim=(MSEarim)^1/2
RMSEhw=(MSEhw)^1/2
RMSEstl=(MSEstl)^1/2
RMSEpromfore=(MSEpromfore)^1/2

###4. error porcentual promedio

ex13por=abs((crecimae2 - forx13)/crecimae2)
earimpor=abs((crecimae2 - forarim)/crecimae2)
ehwpor=abs((crecimae2 -forhW)/crecimae2)
estlpor=abs((crecimae2 - forestl)/crecimae2)
epromforepor=abs((crecimae2 - promfore)/crecimae2)

MAPEX13=(sum(ex13por))/12
MAPEarim=(sum(earimpor))/12
MAPEhw=(sum(ehwpor))/12
MAPEstl=(sum(estlpor))/12
MAPEpromfore=(sum(epromforepor))/12

MAPEX132=MAPE(forx13,crecimae2)
MAPEarim2=MAPE(forarim,crecimae2)
MAPEhw2=MAPE(forhW,crecimae2)
MAPEstl2=MAPE(forestl,crecimae2)
MAPEpromfore2=MAPE(promfore,crecimae2)

###5. coeficiente de Theil

sumy=((1/12)*(sum(crecimae2)))^1/2
sumyfx13=((1/12)*(sum(forx13)))^1/2
sumyfarim=((1/12)*(sum(forarim)))^1/2
sumyfhw=((1/12)*(sum(forhW)))^1/2
sumyfstl=((1/12)*(sum(forestl)))^1/2
sumypromfore=((1/12)*(sum(promfore)))^1/2

theilx13= RMSEX13/(sumy+sumyfx13)
theilarim= RMSEarim/(sumy+sumyfarim)
theilhw= RMSEhw/(sumy+sumyfhw)
theilstl= RMSEstl/(sumy+sumyfstl)
theipromfore= RMSEpromfore/(sumy+sumyfstl)

rm(list=ls())

