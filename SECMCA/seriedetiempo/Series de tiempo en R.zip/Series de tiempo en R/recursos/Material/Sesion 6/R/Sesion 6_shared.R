# Modelos en R para taller
# NOTA:

# El código hay que ajustarlo

library(tidyverse)
library(fredr)
library(forecast)
library(tseries)

source("Sesion 6/R/utils.R")

# Repaso

# Datos ----
# cpi <- fredr(
#   series_id = "CPIAUCSL",
#   observation_start = as.Date("2000-01-01"),
#   frequency = "m",
#   units = "lin"
# ) 


# cpi <- readxl::read_excel("./datos en excel/cpi.xlsx") |> 
#   select(date, value) |> 
#   mutate(
#     d1 = diff(value),
#     vi =
#       )

# Estadistica descriptiva ----
cpi |> 
  ggplot(
    mapping = aes(
      x = date,
      y = value
    )
  )  +
  geom_line() +
  theme_minimal()

# Raiz unitaria ----

# Plot serie no estacionaria:
plota <- cpi |> 
  ggplot(aes(x = date)) +
  geom_line(aes(y = value)) +
  theme_minimal()

# ADF


# PP


# KPSS



# Plot serie estacionaria:
plotb <- cpi |> 
  ggplot(aes(x = date)) +
  geom_line(aes(y = d1)) +
  theme_minimal()

gridExtra::grid.arrange(plota, plotb)

# Pruebas
# ADF


# PP


# KPSS


# Autocorrelacion ----


# PACF
pacf(cpi$d1, 
    lag.max = 15,
    main = "Función de Auto Correlación Parcial: Inflación de EE.UU.")

# AR(1)


# AR(3)



cpi |> 
  mutate(
    ar1 = fitted(),
    ar2 = fitted()
  ) |> 
  select(-c(value, yoy)) |> 
  pivot_longer(cols = !date, 
               names_to = "series_id",
               values_to = "value") |> 
  ggplot(
    mapping = aes(
      x = date,
      y = value,
      color = series_id
    )
  ) +
    geom_line(linewidth = 1) +
  theme_minimal()

# Media movil ----

# ACF
acf(cpi$d1,
     lag.max = 25,
     main = "Función de Auto Correlación: Inflación de EE.UU.")

# El hecho de que caiga geométricamente sugiere que el proceso de la inflación
# es autorregresivo (persistente) y no de media móvil (explicado por choques 
# pasados)

# MA(1)


# MA(3)



cpi |> 
  mutate(
    ma1 = fitted(),
    ma3 = fitted()
  ) |> 
  select(-c(value, yoy)) |> 
  pivot_longer(cols = !date, 
               names_to = "series_id",
               values_to = "value") |> 
  ggplot(
    mapping = aes(
      x = date,
      y = value,
      color = series_id
    )
  ) +
  geom_line(linewidth = 1) +
  theme_minimal()

# Ajuste ----

# AIC
aic_models <- map_dfr(
  .x = c("ar1", "ar3", "ma1", "ma3"),
  .f = get_aic
)


# Autoarima ----


aic_models <- map_dfr(
  .x = arima_orders,
  .f = best_arima
)


# autoarima ----
aa <- auto.arima(cpi$d1)

cpi |> 
  mutate(
    aa = fitted(aa)
  ) |> 
  select(-c(value, yoy)) |> 
  pivot_longer(cols = !date, 
               names_to = "series_id",
               values_to = "value") |> 
  ggplot(
    mapping = aes(
      x = date,
      y = value,
      color = series_id
    )
  ) +
  geom_line(linewidth = 1) +
  theme_minimal()

