# Graficos y tablas
# Sesion 1

# Librerias ----
library(tidyverse)
library(fredr)
library(ggridges)
library(ggplot2)

# Datos ----

# Claves: fredr::fredr_set_key("85b0cd076da563dfe7726d260eb1a285")
# wti <- fredr(
#   series_id = "DCOILWTICO",
#   observation_start = as.Date("2000-01-01"),
#   frequency = "m",
#   units = "pc1"
#   ) 

wti <- readxl::read_excel("./datos en excel/wti.xlsx") |> 
  mutate(year = year(date))

# Estadistica descriptiva ----

wti |> 
  ggplot(
    mapping = aes(
      x = date,
      y = value
    ))  +
  labs(
    title = "Precio Internacional del Petróleo", 
    subtitle = "Variación interanual (%)"
  ) + 
  geom_line() + 
  theme_minimal()

# Incondicional
summary(wti$value)

# Condicional (años)
desc_stats <- wti |>                                 # practica
  summarise(
    minimo = min(value),
    promedio = mean(value),
    mediana = median(value),
    maximo = max(value),
    sd = sd(value),
    .by = year
  )

# Densidad incondicional
wti |> 
  ggplot(aes(x = value)) +
  geom_density() +
  geom_vline(
    mapping = aes(
      xintercept = mean(value)
    )
  ) + 
  theme_minimal()

# Densidad condicional (años)
wti |> 
  filter(
    year >= 2015,
    year <= 2020) |> 
  ggplot(
    mapping = aes(
      x = value,
      y = as.factor(year))) +
  geom_density_ridges() +                            # Nuevo
  theme_minimal()

# Analisis estacional ----

# p_electricity <- fredr(
#   series_id = "APU000072610", # precio promedio de kwH en USA
#   observation_start = as.Date("2015-01-01"),
#   frequency = "m",
#   units = "lin"
# ) |> 
#   select(-c(series_id, realtime_start, realtime_end)) |> 
#   mutate(
#     year = year(date),
#     month = month(date)
#   )

p_electricity <- readxl::read_excel("./datos en excel/p_electricity.xlsx") |> 
  select(-c(series_id, realtime_start, realtime_end)) |> 
  mutate(
    year = year(date),
    month = month(date)
  )


# Gráficos  --------------------------------------------------------------


p_electricity |> 
  ggplot(aes(
    date,
    value
  )) +
  geom_line() +
  theme_minimal()


# Estacional
p_electricity |> 
  ggplot(aes(
    as.factor(month),
    value, 
    group = as.factor(year),
    color = as.factor(year)
  )) +
  geom_line() +
  theme_minimal()


p_electricity |> 
  ggplot(aes(
    as.factor(month),
    value
  )) + 
  geom_boxplot() + 
  theme_minimal()


# Inflacion USA ----
# usa_inf <- map_dfr(c("CPIAUCSL", "DCOILWTICO", "PFOODINDEXM"), 
#                    fredr,
#                    observation_start = as.Date("2000-01-01"),
#                    frequency = "m",
#                    units = "pc1") |> 
#   select(-c(realtime_start, realtime_end))

usa_inf <- readxl::read_excel("./datos en excel/usa_inf.xlsx")

usa_inf |> 
  mutate(series_id = recode(series_id, "CPIAUCSL" = "IPC_USA",
                            "DCOILWTICO" = "P_petroleo",
                            "PFOODINDEXM" = " Índice mundial de precios de los alimentos")) |> 
  ggplot(aes(
    date, value,
    color = series_id)) + 
  geom_line() +
  theme_minimal()


usa_inf |> 
  pivot_wider(
    values_from = value,
    names_from = series_id
  ) |> GGally::ggpairs(columns = 2:4)
  

# Ejercicios para el IMAE

#1. Hacer gráficos del IMAE
#2. Tablas con 
