# Notas:  -----------------------------------------------------------------
# Session 1


# Investigar que explicar los graficos de autocorrelacion y autocorrelacion parcial
# acf() pacf()


# Estacionariedad ---------------------------------------------------------
Estacionariedad:
Proceso será no estacionario si posee raís unitaria: beta menor a -1 y mayor a 1

Proceso será estacionario no posee raíz unitaria: beta entre -1 y 1

test de raiz unitaria:

Test Dickey Fuller Aumentado

Su h0 es que la serie posee raíz unitaria
# -----------------
# Si modelizamos sin considerar la estacionariedad:

+ Los shock persisten en el tiempo.
+ Las distribuciones de los tests no son normales
+ Los pronósticos podrían ser poco precisos
+ Coeficientes sesgados


# Cointegración -----------------------------------------------------------

# Dos o más series de tiempo están cointegradas si las mismas se mueven conjuntamente a lo largo del tiempo, aun cuando cada serie en particular contenga una tendencia estocástica y sea por lo tanto no estacionaria.

$$y_t= \hat{\beta_0} + \hat{\beta_1}X_t + \hat{\beta_2}Z_t+\epsilon_t$$

# Comprobar cointegración entre dos o más variables han sido dos:

+ Engel-Granger
    + Aplicable a modelos multiecuacionales
    + Método en dos etapas basado en los    residuos estimados (Famosos B en las formulas)


+ Johansen


# Como testear la cointegración en R:
1. Realizar pruebas de raíz unitaria sobre las series y determinar el orden de integración.

2. Se realizará el test de integraca.............

#                           Test
ENGEL:
Si las series son estacionarias de orde I(0) apliquen el procedimiento estandar de MCO. resultado: parámetros exactos y superconsistentes. 

Si las series resultan integradas de diferente ordem, tales como: I(0), I(1) y ..............

Johansen:
Los detalles teóricos de la prueba de Johansen requieren un poco de experiencia con series temporales multivardas. Se parte de considerar modelos vectoriales autorregresivos (VAR), que son una extensión multidimensional de los modelos autorregresivos estudiados anteriomente (ARIMA).

Phillip-Ouliaris:


# Vectores Autorregresivo con Corrección de Errores (VECM) ----------------

# Estos son una extension de los VAR y se elabora a partir de series de tiempo no estacionarias, pero que cointegran

